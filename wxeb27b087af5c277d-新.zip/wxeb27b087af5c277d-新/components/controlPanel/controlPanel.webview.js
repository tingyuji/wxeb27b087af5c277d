$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'panel '],[[2,'?:'],[[7],[3,'visible']],[1,'show'],[1,'']]])
Z([3,'content'])
Z([3,'preset-grid'])
Z([[7],[3,'presetColors']])
Z([3,'index'])
Z([3,'onPresetSelect'])
Z([3,'preset-item'])
Z([[7],[3,'item']])
Z([3,'preset-color'])
Z([a,[3,'background-color:'],z[7]])
Z([3,'preset-name'])
Z([a,[[6],[[7],[3,'presetNames']],[[7],[3,'index']]]])
Z([3,'color-slider-container'])
Z([3,'transparent'])
Z(z[13])
Z([3,'onHueChange'])
Z([3,'onSliderTouchEnd'])
Z([3,'onSliderTouchStart'])
Z([3,'#FFFFFF'])
Z([3,'28'])
Z([3,'color-slider'])
Z([3,'360'])
Z([3,'0'])
Z([[7],[3,'hueValue']])
Z([3,'bottom-controls'])
Z([3,'control-item'])
Z([3,'control-label'])
Z([a,[[7],[3,'saturation']],[3,'%']])
Z([3,'饱和度'])
Z([3,'#8A2BE2'])
Z([3,'rgba(255, 255, 255, 0.1)'])
Z([3,'onSaturationChange'])
Z(z[16])
Z(z[17])
Z(z[18])
Z(z[19])
Z([3,'control-slider'])
Z([3,'100'])
Z(z[22])
Z(z[27][1])
Z(z[25])
Z(z[26])
Z([a,[[7],[3,'screenBrightness']],z[27][2]])
Z([3,'屏幕亮度'])
Z(z[29])
Z(z[30])
Z([3,'onBrightnessChange'])
Z(z[16])
Z(z[17])
Z(z[18])
Z(z[19])
Z(z[36])
Z(z[37])
Z(z[22])
Z(z[42][1])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/controlPanel/controlPanel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var lY=_mz(z,'view',['catch:tap',-1,'class',0],[],e,s,gg)
var aZ=_mz(z,'view',['catch:tap',-1,'class',1],[],e,s,gg)
var t1=_n('view')
_rz(z,t1,'class',2,e,s,gg)
var e2=_v()
_(t1,e2)
var b3=function(x5,o4,o6,gg){
var c8=_mz(z,'view',['bind:tap',5,'class',1,'data-color',2],[],x5,o4,gg)
var h9=_mz(z,'view',['class',8,'style',1],[],x5,o4,gg)
_(c8,h9)
var o0=_n('text')
_rz(z,o0,'class',10,x5,o4,gg)
var cAB=_oz(z,11,x5,o4,gg)
_(o0,cAB)
_(c8,o0)
_(o6,c8)
return o6
}
e2.wxXCkey=2
_2z(z,3,b3,e,s,gg,e2,'item','index','index')
_(aZ,t1)
var oBB=_n('view')
_rz(z,oBB,'class',12,e,s,gg)
var lCB=_mz(z,'slider',['activeColor',13,'backgroundColor',1,'bind:change',2,'bindtouchend',3,'bindtouchstart',4,'blockColor',5,'blockSize',6,'class',7,'max',8,'min',9,'value',10],[],e,s,gg)
_(oBB,lCB)
_(aZ,oBB)
var aDB=_n('view')
_rz(z,aDB,'class',24,e,s,gg)
var tEB=_n('view')
_rz(z,tEB,'class',25,e,s,gg)
var eFB=_mz(z,'text',['class',26,'data-value',1],[],e,s,gg)
var bGB=_oz(z,28,e,s,gg)
_(eFB,bGB)
_(tEB,eFB)
var oHB=_mz(z,'slider',['activeColor',29,'backgroundColor',1,'bind:change',2,'bindtouchend',3,'bindtouchstart',4,'blockColor',5,'blockSize',6,'class',7,'max',8,'min',9,'value',10],[],e,s,gg)
_(tEB,oHB)
_(aDB,tEB)
var xIB=_n('view')
_rz(z,xIB,'class',40,e,s,gg)
var oJB=_mz(z,'text',['class',41,'data-value',1],[],e,s,gg)
var fKB=_oz(z,43,e,s,gg)
_(oJB,fKB)
_(xIB,oJB)
var cLB=_mz(z,'slider',['activeColor',44,'backgroundColor',1,'bind:change',2,'bindtouchend',3,'bindtouchstart',4,'blockColor',5,'blockSize',6,'class',7,'max',8,'min',9,'value',10],[],e,s,gg)
_(xIB,cLB)
_(aDB,xIB)
_(aZ,aDB)
_(lY,aZ)
_(r,lY)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/controlPanel/controlPanel.wxml'] = [$gwx_XC_4, './components/controlPanel/controlPanel.wxml'];else __wxAppCode__['components/controlPanel/controlPanel.wxml'] = $gwx_XC_4( './components/controlPanel/controlPanel.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/controlPanel/controlPanel.wxss'] = setCssToHead([".",[1],"panel{-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);background:rgba(0,0,0,.85);border-radius:",[0,32]," ",[0,32]," 0 0;bottom:0;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;left:0;max-height:65vh;min-height:40vh;opacity:0;position:fixed;-webkit-transform:translateY(100%);transform:translateY(100%);transition:all .4s cubic-bezier(.16,1,.3,1);width:100%;z-index:100}\n.",[1],"panel.",[1],"show{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}\n.",[1],"panel::after{background:rgba(0,0,0,.4);bottom:0;content:\x22\x22;left:0;opacity:0;pointer-events:none;position:fixed;right:0;top:0;transition:opacity .4s ease;z-index:-1}\n.",[1],"panel.",[1],"show::after{opacity:1}\n.",[1],"content{-webkit-overflow-scrolling:touch;-webkit-flex:1;flex:1;overflow-y:auto;padding:",[0,24]," ",[0,32]," calc(env(safe-area-inset-bottom) + ",[0,32],")}\n.",[1],"panel::before{background:hsla(0,0%,100%,.3);border-radius:",[0,2],";content:\x22\x22;height:",[0,4],";left:50%;position:absolute;top:",[0,16],";-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,36],"}\n.",[1],"preset-grid{display:grid;gap:",[0,24],";grid-template-columns:repeat(4,1fr);margin-top:",[0,24],";padding:0 ",[0,32],"}\n.",[1],"preset-item{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;gap:",[0,8],"}\n.",[1],"preset-color{aspect-ratio:1.618;border-radius:",[0,16],";box-shadow:0 ",[0,2]," ",[0,8]," rgba(0,0,0,.1);transition:-webkit-transform .2s ease;transition:transform .2s ease;transition:transform .2s ease,-webkit-transform .2s ease;width:100%}\n.",[1],"preset-item:active .",[1],"preset-color{-webkit-transform:scale(.95);transform:scale(.95)}\n.",[1],"preset-name{color:hsla(0,0%,100%,.9);font-size:",[0,22],";margin-top:",[0,4],"}\n.",[1],"bottom-controls{background:hsla(0,0%,100%,.05);border-radius:",[0,24],";margin-left:",[0,32],";margin-right:",[0,32],";margin-top:",[0,32],";padding:",[0,32],"}\n.",[1],"control-item{margin-bottom:",[0,24],"}\n.",[1],"control-item:last-child{margin-bottom:0}\n.",[1],"control-label{-webkit-align-items:center;align-items:center;color:hsla(0,0%,100%,.9);display:-webkit-flex;display:flex;font-size:",[0,22],";-webkit-justify-content:space-between;justify-content:space-between;margin-bottom:",[0,16],"}\n.",[1],"control-label::after{color:hsla(0,0%,100%,.5);content:attr(data-value)}\n.",[1],"control-slider{margin:0;width:100%}\n.",[1],"control-slider .",[1],"wx-slider-handle{background:#fff!important;box-shadow:0 ",[0,2]," ",[0,8]," rgba(0,0,0,.2);height:",[0,28],"!important;width:",[0,28],"!important}\n.",[1],"control-slider .",[1],"wx-slider-track{height:",[0,4],"!important}\n.",[1],"color-slider-container{background:hsla(0,0%,100%,.05);border-radius:",[0,22],";height:",[0,44],";margin:",[0,32],";overflow:hidden;padding:",[0,8],";position:relative}\n.",[1],"color-slider-container::before{background:linear-gradient(90deg,red,#ff7f00,#ff0,#0f0,#0ff,#00f,#8b00ff,red);border-radius:",[0,22],";bottom:0;content:\x22\x22;left:0;position:absolute;right:0;top:0;z-index:0}\n.",[1],"color-slider{margin:0;position:relative;width:100%;z-index:1}\n.",[1],"color-slider .",[1],"wx-slider-handle{background:#fff!important;border:",[0,2]," solid hsla(0,0%,100%,.8);box-shadow:0 ",[0,2]," ",[0,8]," rgba(0,0,0,.2);height:",[0,28],"!important;width:",[0,28],"!important}\n.",[1],"color-slider .",[1],"wx-slider-track{background:transparent!important}\n",],undefined,{path:"./components/controlPanel/controlPanel.wxss"});
}