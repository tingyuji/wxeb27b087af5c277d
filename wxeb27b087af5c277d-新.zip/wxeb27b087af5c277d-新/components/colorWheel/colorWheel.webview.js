$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'wheel-container'])
Z([3,'onWheelTouchMove'])
Z([3,'onWheelTouchStart'])
Z([3,'color-wheel'])
Z([3,'wheel-gradient'])
Z([3,'color-indicator'])
Z([a,[3,'transform:rotate('],[[7],[3,'hue']],[3,'deg) translateX('],[[2,'*'],[[7],[3,'saturation']],[1,120]],[3,'rpx)']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./components/colorWheel/colorWheel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var cT=_n('view')
_rz(z,cT,'class',0,e,s,gg)
var hU=_mz(z,'view',['bind:touchmove',1,'bind:touchstart',1,'class',2],[],e,s,gg)
var oV=_n('view')
_rz(z,oV,'class',4,e,s,gg)
var cW=_mz(z,'view',['class',5,'style',1],[],e,s,gg)
_(oV,cW)
_(hU,oV)
_(cT,hU)
_(r,cT)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/colorWheel/colorWheel.wxml'] = [$gwx_XC_3, './components/colorWheel/colorWheel.wxml'];else __wxAppCode__['components/colorWheel/colorWheel.wxml'] = $gwx_XC_3( './components/colorWheel/colorWheel.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/colorWheel/colorWheel.wxss'] = setCssToHead([".",[1],"wheel-container{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;padding:",[0,40],"}\n.",[1],"color-wheel{background:conic-gradient(from 0deg,red,#ff0,#0f0,#0ff,#00f,#f0f,red);border-radius:50%;height:",[0,500],";position:relative;width:",[0,500],"}\n.",[1],"wheel-gradient{background:radial-gradient(circle at center,#fff 0,transparent 70%);border-radius:50%;height:100%;width:100%}\n.",[1],"color-indicator{background:currentColor;border:",[0,4]," solid #fff;border-radius:50%;box-shadow:0 0 ",[0,10]," rgba(0,0,0,.3);height:",[0,40],";left:50%;margin:",[0,-20],";position:absolute;top:50%;width:",[0,40],"}\n",],undefined,{path:"./components/colorWheel/colorWheel.wxss"});
}