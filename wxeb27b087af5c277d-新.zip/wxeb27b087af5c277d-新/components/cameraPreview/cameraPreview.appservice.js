$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/cameraPreview/cameraPreview.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/cameraPreview/cameraPreview.wxml'] = [$gwx_XC_2, './components/cameraPreview/cameraPreview.wxml'];else __wxAppCode__['components/cameraPreview/cameraPreview.wxml'] = $gwx_XC_2( './components/cameraPreview/cameraPreview.wxml' );
	;__wxRoute = "components/cameraPreview/cameraPreview";__wxRouteBegin = true;__wxAppCurrentFile__="components/cameraPreview/cameraPreview.js";define("components/cameraPreview/cameraPreview.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/regeneratorRuntime"),t=require("../../@babel/runtime/helpers/asyncToGenerator");Component({properties:{mirror:{type:Boolean,value:!0}},data:{scale:1,x:0,y:0},methods:{onScale:function(e){var t=Math.min(Math.max(e.detail.scale,.7),1.5);this.setData({scale:t})},onTouchMove:function(e){var t=e.detail,r=t.x,n=t.y;this.setData({x:r,y:n})},takePhoto:function(){return t(e().mark((function t(){var r;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,r=wx.createCameraContext(),e.abrupt("return",new Promise((function(e,t){r.takePhoto({quality:"high",success:function(t){e(t)},fail:function(e){console.error("拍照失败:",e),t(e)}})})));case 5:throw e.prev=5,e.t0=e.catch(0),console.error("创建相机上下文失败:",e.t0),e.t0;case 9:case"end":return e.stop()}}),t,null,[[0,5]])})))()},takeVideo:function(r){return t(e().mark((function t(){var n;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,n=wx.createCameraContext(),e.abrupt("return",new Promise((function(e,t){n.startRecord({success:function(a){setTimeout((function(){n.stopRecord({success:function(t){e(t)},fail:t})}),r)},fail:t})})));case 5:throw e.prev=5,e.t0=e.catch(0),console.error("创建相机上下文失败:",e.t0),e.t0;case 9:case"end":return e.stop()}}),t,null,[[0,5]])})))()}}});
},{isPage:false,isComponent:true,currentFile:'components/cameraPreview/cameraPreview.js'});require("components/cameraPreview/cameraPreview.js");