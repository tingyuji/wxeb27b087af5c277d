$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'shutter-container'])
Z([[7],[3,'showTip']])
Z([3,'tip'])
Z([3,'长按我可以倒计时拍照哦 ⏰'])
Z([3,'onLongPress'])
Z([3,'onTap'])
Z([a,[3,'shutter '],[[2,'?:'],[[7],[3,'isCountingDown']],[1,'counting'],[1,'']]])
Z([3,'inner-circle'])
Z([[7],[3,'isCountingDown']])
Z([3,'countdown'])
Z([a,[[7],[3,'countdown']]])
Z(z[8])
Z([3,'progress'])
Z([3,'progress-circle'])
Z([a,[3,'animation-duration:'],[[7],[3,'countdown']],[3,'s']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/shutterButton/shutterButton.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var oNB=_n('view')
_rz(z,oNB,'class',0,e,s,gg)
var cOB=_v()
_(oNB,cOB)
if(_oz(z,1,e,s,gg)){cOB.wxVkey=1
var oPB=_n('view')
_rz(z,oPB,'class',2,e,s,gg)
var lQB=_oz(z,3,e,s,gg)
_(oPB,lQB)
_(cOB,oPB)
}
var aRB=_mz(z,'view',['bind:longpress',4,'bind:tap',1,'class',2],[],e,s,gg)
var eTB=_n('view')
_rz(z,eTB,'class',7,e,s,gg)
var bUB=_v()
_(eTB,bUB)
if(_oz(z,8,e,s,gg)){bUB.wxVkey=1
var oVB=_n('view')
_rz(z,oVB,'class',9,e,s,gg)
var xWB=_oz(z,10,e,s,gg)
_(oVB,xWB)
_(bUB,oVB)
}
bUB.wxXCkey=1
_(aRB,eTB)
var tSB=_v()
_(aRB,tSB)
if(_oz(z,11,e,s,gg)){tSB.wxVkey=1
var oXB=_n('view')
_rz(z,oXB,'class',12,e,s,gg)
var fYB=_mz(z,'view',['class',13,'style',1],[],e,s,gg)
_(oXB,fYB)
_(tSB,oXB)
}
tSB.wxXCkey=1
_(oNB,aRB)
cOB.wxXCkey=1
_(r,oNB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/shutterButton/shutterButton.wxml'] = [$gwx_XC_5, './components/shutterButton/shutterButton.wxml'];else __wxAppCode__['components/shutterButton/shutterButton.wxml'] = $gwx_XC_5( './components/shutterButton/shutterButton.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/shutterButton/shutterButton.wxss'] = setCssToHead([".",[1],"shutter-container{position:relative}\n.",[1],"tip{background:rgba(0,0,0,.7);border-radius:",[0,100],";color:#fff;font-size:",[0,28],";left:50%;padding:",[0,16]," ",[0,32],";position:absolute;top:",[0,-80],";-webkit-transform:translateX(-50%);transform:translateX(-50%);white-space:nowrap}\n.",[1],"shutter{-webkit-animation:breath 2s infinite;animation:breath 2s infinite;background:hsla(0,0%,100%,.2);height:",[0,168],";position:relative;width:",[0,168],"}\n.",[1],"inner-circle,.",[1],"shutter{-webkit-align-items:center;align-items:center;border-radius:50%;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"inner-circle{background:#fff;height:",[0,132],";width:",[0,132],"}\n.",[1],"countdown{color:#000;font-size:",[0,60],";font-weight:700}\n.",[1],"progress{height:100%;position:absolute;width:100%}\n.",[1],"progress-circle{-webkit-animation:countdown linear;animation:countdown linear;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;border:",[0,4]," solid #fff;border-radius:50%;-webkit-clip-path:circle(50%);clip-path:circle(50%);height:100%;width:100%}\n@-webkit-keyframes breath{0%,100%{opacity:.8;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1.05);transform:scale(1.05)}\n}@keyframes breath{0%,100%{opacity:.8;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1.05);transform:scale(1.05)}\n}@-webkit-keyframes countdown{from{-webkit-clip-path:circle(50% at 50% 50%);clip-path:circle(50% at 50% 50%)}\nto{-webkit-clip-path:circle(0 at 50% 50%);clip-path:circle(0 at 50% 50%)}\n}@keyframes countdown{from{-webkit-clip-path:circle(50% at 50% 50%);clip-path:circle(50% at 50% 50%)}\nto{-webkit-clip-path:circle(0 at 50% 50%);clip-path:circle(0 at 50% 50%)}\n}.",[1],"shutter.",[1],"counting .",[1],"inner-circle{-webkit-transform:scale(.9);transform:scale(.9)}\n",],undefined,{path:"./components/shutterButton/shutterButton.wxss"});
}