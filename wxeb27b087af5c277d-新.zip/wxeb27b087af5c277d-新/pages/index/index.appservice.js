$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handlePageTap'])
Z([3,'handleTouchEnd'])
Z([3,'handleTouchStart'])
Z([3,'container container-content'])
Z([3,'container'])
Z([a,[3,'background-color:'],[[7],[3,'currentColor']],[3,';']])
Z([[7],[3,'showCamera']])
Z([3,'preview'])
Z([[7],[3,'isMirror']])
Z([3,'width:54vw;height:30vh;top:6vh;'])
Z([3,'handlePhotoTaken'])
Z([3,'toggleCameraMode'])
Z([3,'camera'])
Z([[7],[3,'isCameraMode']])
Z(z[13])
Z([[7],[3,'isPanelVisible']])
Z([3,'handleColorChange'])
Z([3,'handleSaturationChange'])
Z([3,'handleSliderTouchEnd'])
Z([3,'handleSliderTouchStart'])
Z([3,'stopPropagation'])
Z(z[5][2])
Z([1,true])
Z([[2,'!'],[[7],[3,'isPanelVisible']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var bO=_mz(z,'view',['bindtap',0,'bindtouchend',1,'bindtouchstart',1,'class',2,'data-area',3,'style',4],[],e,s,gg)
var oP=_v()
_(bO,oP)
if(_oz(z,6,e,s,gg)){oP.wxVkey=1
var cT=_mz(z,'camera-preview',['class',7,'mirror',1,'style',2],[],e,s,gg)
_(oP,cT)
}
var hU=_mz(z,'camera-component',['bind:photo',10,'bind:toggle',1,'id',2,'show',3],[],e,s,gg)
_(bO,hU)
var xQ=_v()
_(bO,xQ)
if(_oz(z,14,e,s,gg)){xQ.wxVkey=1
}
var oR=_v()
_(bO,oR)
if(_oz(z,15,e,s,gg)){oR.wxVkey=1
var oV=_mz(z,'control-panel',['bind:colorChange',16,'bind:saturationChange',1,'bind:sliderTouchEnd',2,'bind:sliderTouchStart',3,'catch:tap',4,'currentColor',5,'visible',6],[],e,s,gg)
_(oR,oV)
}
var fS=_v()
_(bO,fS)
if(_oz(z,23,e,s,gg)){fS.wxVkey=1
}
oP.wxXCkey=1
oP.wxXCkey=3
xQ.wxXCkey=1
oR.wxXCkey=1
oR.wxXCkey=3
fS.wxXCkey=1
_(r,bO)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_7, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_7( './pages/index/index.wxml' );
	;__wxRoute = "pages/index/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/index/index.js";define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../@babel/runtime/helpers/Objectvalues");var t=require("../../@babel/runtime/helpers/regeneratorRuntime"),e=require("../../@babel/runtime/helpers/asyncToGenerator");Page({data:{isPanelVisible:!0,showCamera:!1,currentColor:"#8A2BE2",isFirstLaunch:!0,isMirror:!0,isLivePhotoEnabled:!1,presetColors:[],currentPresetIndex:0,isSliding:!1,isCameraMode:!1,cameraPosition:"front",isCameraReady:!1},onLoad:function(){var t=this,e=require("../../constants/presets").PRESET_COLORS;wx.setScreenBrightness({value:1,success:function(){console.log("屏幕亮度已设置为最大")}}),this.setData({presetColors:Object.values(e),currentColor:e.SKIN_SMOOTH,isPanelVisible:!0}),setTimeout((function(){t.setData({isCameraReady:!0})}),300)},openCamera:function(){var a=this;return e(t().mark((function e(){var n;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.prev=0,t.next=3,wx.getSetting();case 3:if(n=t.sent,n.authSetting["scope.camera"]){t.next=8;break}return t.next=8,wx.authorize({scope:"scope.camera"});case 8:a.setData({showCamera:!0,isPanelVisible:!1}),t.next=14;break;case 11:t.prev=11,t.t0=t.catch(0),wx.showToast({title:"无法打开相机",icon:"none"});case 14:case"end":return t.stop()}}),e,null,[[0,11]])})))()},closeCamera:function(){this.setData({showCamera:!1})},onShutterTap:function(){this.data.isFirstLaunch&&(wx.vibrateShort(),this.setData({isFirstLaunch:!1}),wx.setStorage({key:"hasUsedCamera",data:!0})),this.takePhoto()},onShutterLongPress:function(){wx.vibrateShort(),this.startCountdown()},onPanelClose:function(){console.log("关闭控制面板"),this.setData({isPanelVisible:!1})},handleColorChange:function(t){this.setData({currentColor:t.detail.color})},takePhoto:function(){var a=this;return e(t().mark((function e(){var n,o,r;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(t.prev=0,wx.vibrateShort(),n=a.selectComponent(".preview")){t.next=5;break}throw new Error("相机组件未找到");case 5:if(!a.data.isLivePhotoEnabled){t.next=14;break}return wx.showToast({title:"Live Photo 保存中...",icon:"loading",duration:2e3}),t.next=9,n.takeVideo(1500);case 9:return o=t.sent,t.next=12,a.saveLivePhoto(o);case 12:t.next=20;break;case 14:return t.next=16,n.takePhoto();case 16:return r=t.sent,console.log("拍照成功:",r),t.next=20,a.savePhoto(r);case 20:t.next=26;break;case 22:t.prev=22,t.t0=t.catch(0),console.error("拍照失败:",t.t0),wx.showToast({title:"拍照失败: "+t.t0.message,icon:"none"});case 26:case"end":return t.stop()}}),e,null,[[0,22]])})))()},startCountdown:function(){},savePhoto:function(a){return e(t().mark((function e(){return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.prev=0,t.next=3,wx.saveImageToPhotosAlbum({filePath:a.tempImagePath});case 3:wx.showToast({title:"已保存到相册 📸",icon:"none"}),t.next=9;break;case 6:t.prev=6,t.t0=t.catch(0),wx.showToast({title:"保存失败",icon:"none"});case 9:case"end":return t.stop()}}),e,null,[[0,6]])})))()},toggleMirror:function(){this.setData({isMirror:!this.data.isMirror})},toggleLivePhoto:function(){this.setData({isLivePhotoEnabled:!this.data.isLivePhotoEnabled})},handlePanelToggle:function(t){t.stopPropagation(),this.setData({isPanelVisible:!this.data.isPanelVisible})},handlePageTap:function(t){var e=this;"container"===t.target.dataset.area&&(console.log("点击容器区域，当前面板状态:",this.data.isPanelVisible),this.setData({isPanelVisible:!this.data.isPanelVisible},(function(){console.log("面板状态已更新为:",e.data.isPanelVisible)})))},stopPropagation:function(t){console.log("【Page】stopPropagation called"),t.stopPropagation()},touchStartX:0,touchStartY:0,touchStartTime:0,handleTouchStart:function(t){this.touchStartX=t.touches[0].clientX,this.touchStartY=t.touches[0].clientY,this.touchStartTime=Date.now()},handleTouchEnd:function(t){if(!this.data.isSliding){var e=t.changedTouches[0].clientX,a=t.changedTouches[0].clientY,n=e-this.touchStartX,o=Math.abs(a-this.touchStartY),r=Date.now()-this.touchStartTime;if(Math.abs(n)>50&&o<Math.abs(n)/2&&r<300){var s,i=this.data,c=i.presetColors,h=i.currentPresetIndex;s=n>0?(h-1+c.length)%c.length:(h+1)%c.length;var u=require("../../constants/presets").PRESET_NAMES,l=Object.values(u)[s];this.setData({currentPresetIndex:s,currentColor:c[s]}),wx.vibrateShort({type:"light"}),wx.showToast({title:l,icon:"none",duration:500})}}},handleSaturationChange:function(t){var e=this.data.currentColor,a=t.detail.value,n=this.adjustColorSaturation(e,a);this.setData({currentColor:n})},adjustColorSaturation:function(t,e){var a=.5+e/100*.5;t=t.replace("#","");var n=parseInt(t.substr(0,2),16),o=parseInt(t.substr(2,2),16),r=parseInt(t.substr(4,2),16),s=(299*n+587*o+114*r)/1e3,i=function(t){return a>.75?Math.min(255,Math.round(t*(1+.5*(a-.75)))):Math.round(t*a+s*(1-a))},c=i(n),h=i(o),u=i(r),l=function(t){var e=t.toString(16);return 1===e.length?"0"+e:e};return"#".concat(l(c)).concat(l(h)).concat(l(u))},handleSliderTouchStart:function(){this.setData({isSliding:!0})},handleSliderTouchEnd:function(){var t=this;setTimeout((function(){t.setData({isSliding:!1})}),100)},toggleCameraMode:function(){var t=this,e=!this.data.isCameraMode;console.log("切换相机模式:",e),this.setData({isCameraMode:e,showCamera:e,isPanelVisible:!e},(function(){console.log("相机模式已更新:",t.data.isCameraMode)}))},handleCameraCapture:function(a){var n=this;return e(t().mark((function e(){var o;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(a.stopPropagation(),t.prev=1,o=n.selectComponent("#camera")){t.next=5;break}throw new Error("相机组件未找到");case 5:o.takePhoto(),t.next=11;break;case 8:t.prev=8,t.t0=t.catch(1),wx.showToast({title:"拍照失败",icon:"none"});case 11:case"end":return t.stop()}}),e,null,[[1,8]])})))()},handlePhotoTaken:function(t){var e=t.detail.tempImagePath;this.savePhoto({tempImagePath:e}),wx.showToast({title:"已保存",icon:"success",duration:1500})}});
},{isPage:true,isComponent:true,currentFile:'pages/index/index.js'});require("pages/index/index.js");